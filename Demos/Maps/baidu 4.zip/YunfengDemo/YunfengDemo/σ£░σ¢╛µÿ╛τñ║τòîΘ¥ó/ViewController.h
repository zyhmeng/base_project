//
//  ViewController.h
//  YunfengDemo
//
//  Created by Hudasen on 15/11/10.
//  Copyright © 2015年 Hudasen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    BMKLocationService* _locService;
}

@end

