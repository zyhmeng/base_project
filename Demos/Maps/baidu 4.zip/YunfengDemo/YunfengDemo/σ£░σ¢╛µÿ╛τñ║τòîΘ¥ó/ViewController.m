//
//  ViewController.m
//  YunfengDemo
//
//  Created by Hudasen on 15/11/10.
//  Copyright © 2015年 Hudasen. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<BMKMapViewDelegate,BMKLocationServiceDelegate>
@property (weak, nonatomic) IBOutlet BMKMapView *mapView;
- (IBAction)LocationButton:(UIButton *)sender;
- (IBAction)FreshButton:(UIButton *)sender;

@property(nonatomic,copy)NSMutableArray *locationAry;//存放大头针对象

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _locationAry = [[NSMutableArray alloc] init];
    
    //初始化百度地图对象
    [_locService startUserLocationService];//启动定位功能
    _mapView.showsUserLocation = YES;//显示定位图层
    [_mapView setMapType:BMKMapTypeStandard];
     _mapView.userTrackingMode = BMKUserTrackingModeNone;//设置定位的状态
    _mapView.zoomLevel = 12;//地图级别
    _mapView.delegate = self;
    
    CLLocationCoordinate2D coor;
    if (_locService.userLocation.location != nil) {
        
        coor = _locService.userLocation.location.coordinate;
        
    }else{
        coor.latitude = Latitude;
        coor.longitude = Longitude;
    }
    
    BMKCoordinateRegion viewRegion = BMKCoordinateRegionMake(coor, BMKCoordinateSpanMake(0.2, 0.2));
    BMKCoordinateRegion adjustedRegion = [_mapView regionThatFits:viewRegion];
    [_mapView setRegion:adjustedRegion animated:YES];

    [self fetchdata];
}


//数据初始化
-(void)fetchdata{
    
    [_locationAry removeAllObjects];
    for (int i = 0; i < 3; i++) {
        
        //设置标注点
       BMKPointAnnotation *pointAnnotation = [[BMKPointAnnotation alloc] init];
        CLLocationCoordinate2D coor;
        coor.latitude = Latitude + i*0.1;
        coor.longitude = Longitude;
        pointAnnotation.coordinate = coor;
        pointAnnotation.title = @"中国人";
        
        [_locationAry addObject:pointAnnotation];
        
        NSLog(@"%f %f",coor.latitude,coor.longitude);
    }
    
    //自定义
    CustomAnnotation *customannotation = [[CustomAnnotation alloc] init];
    CLLocationCoordinate2D coorcustom;
    coorcustom.latitude = Latitude;
    coorcustom.longitude = Longitude + 0.3;
    customannotation.myCoordinate = coorcustom;
    customannotation.imagename = @"3.png";
    customannotation.content = @"绿地天下峰会";
    customannotation.myTitle = @"123456";
    [_locationAry addObject:customannotation];
    
    
    //测试测试圆形区域内合法目标，此时需要三个参数：标注对象，距离，标注存放数组_locationAry;
//        NSMutableArray *array = [self centerForsearchthird:customannotation radiusForsearch:1000000 searchTotarget:_locationAry];
    
    //测试正方形区域内合法目标
//    NSMutableArray *array = [self searchForcenterSecond:customannotation radiusForsearch:80000 searchTotarget:_locationAry];
    
//    NSLog(@"测试距离%@",array);
}

-(void)viewWillAppear:(BOOL)animated{
    
    [_mapView viewWillAppear];
    _mapView.delegate = self;
    _locService.delegate = self;
}

-(void)viewDidAppear:(BOOL)animated{
    //添加标注
    [_mapView addAnnotations:_locationAry];
}

-(void)viewWillDisappear:(BOOL)animated{
    [_mapView viewWillDisappear];
    _mapView.delegate = self;
    _locService.delegate = self;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



-(BMKAnnotationView *)mapView:(BMKMapView *)mapView viewForAnnotation:(id<BMKAnnotation>)annotation{
    
    //普通annotation
    if ([annotation isKindOfClass:[BMKPointAnnotation class]]) {
        NSString *AnnotationViewID = @"renameMark";
        BMKPinAnnotationView *annotationView = (BMKPinAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:AnnotationViewID];
        if (annotationView == nil) {
            annotationView = [[BMKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:AnnotationViewID];
            // 设置颜色
            annotationView.pinColor = BMKPinAnnotationColorPurple;
            // 从天上掉下效果
            annotationView.animatesDrop = YES;
            // 设置可拖拽
            annotationView.draggable = YES;
            
            BMKPointAnnotation *lannotation = annotation;
                    //使用MyView来自定义气泡
                    MyView *view = [[MyView alloc] initWithFrame:CGRectMake(0, 0, 100, 60)];
                    view.la = [annotation coordinate].latitude;
                    view.lon = [annotation coordinate].longitude;
                    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 10, 100, 20)];
                    label.text = lannotation.title;
                    [view addSubview:label];
                    label.userInteractionEnabled = YES;
                    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
            
                    [view addGestureRecognizer:tapGesture];
                    BMKActionPaopaoView *pView = [[BMKActionPaopaoView alloc] initWithCustomView:view];
                    pView.frame = CGRectMake(0, 0, 100, 60);
                    ((BMKPinAnnotationView*)annotationView).paopaoView = nil;
                    ((BMKPinAnnotationView *)annotationView).paopaoView = pView;
        }
       return annotationView;
    } else if([annotation isKindOfClass:[CustomAnnotation class]]){
        CustomAnnotation *custAnnotation = annotation;
        static NSString *AnimatedID = @"AnimatedID";
        BMKPinAnnotationView *anotataionView = (BMKPinAnnotationView*)[mapView dequeueReusableAnnotationViewWithIdentifier:AnimatedID];
        if (anotataionView == nil) {
            anotataionView = [[BMKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:AnimatedID];
        }

        anotataionView.image = [UIImage imageNamed:custAnnotation.imagename];
        anotataionView.draggable = YES;
        anotataionView.animatesDrop = YES;

        //设置气泡
        MyView *view = [[MyView alloc] initWithFrame:CGRectMake(0, 0, 100, 60)];
        [view setBackgroundColor:[UIColor yellowColor]];
        view.la = [annotation coordinate].latitude;
        view.lon = [annotation coordinate].longitude;
        
        UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 10, 100, 20)];
        label.text = custAnnotation.content;
        label.textColor = [UIColor redColor];
        label.userInteractionEnabled = YES;
        [view addSubview:label];
        
        UILabel *label2 = [[UILabel alloc] initWithFrame:CGRectMake(0, 30, 100, 20)];
        label2.text = custAnnotation.myTitle;
        label2.userInteractionEnabled = YES;
        [view addSubview:label2];
        [view addGestureRecognizer:tapGesture];
        
        BMKActionPaopaoView *pView = [[BMKActionPaopaoView alloc] initWithCustomView:view];
        pView.frame = CGRectMake(0, 0, 100, 60);
        ((BMKPinAnnotationView*)anotataionView).paopaoView = nil;
        ((BMKPinAnnotationView *)anotataionView).paopaoView = pView;
         return anotataionView;
    }
    return nil;
}


//点击气泡触发的方法
-(void)tapAction:(UITapGestureRecognizer *)sender{
   
  MyView *myview = (MyView *)sender.view;
    DetailController *detailcontroller = [[DetailController alloc] init];
    
        detailcontroller.DetailLatitude = myview.la;
        detailcontroller.DetailLongitude = myview.lon;
    [self presentViewController:detailcontroller animated:YES completion:nil];
}

#pragma mark 刷新定位
- (IBAction)LocationButton:(UIButton *)sender {
    
    NSLog(@"进入定位");
    [_locService startUserLocationService]; //开启定位功能
}

#pragma mark 时时刷新
- (IBAction)FreshButton:(UIButton *)sender {
    
    [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(freshView:) userInfo:nil repeats:YES];
}

-(void)freshView:(id)sender{
    
    NSLog(@"时时刷新位置");
    [_locService startUserLocationService]; //开启定位功能
}

#pragma mark --BMKLocationServiceDelegate 代理方法
/**
 *在地图View将要启动定位时，会调用此函数
 *@param mapView 地图View
 */
- (void)willStartLocatingUser
{
    NSLog(@"start locate");
}

/**
 *用户位置更新后，会调用此函数
 *@param userLocation 新的用户位置
 */
- (void)didUpdateBMKUserLocation:(BMKUserLocation *)userLocation
{
    //当前位置显示在可视范围内
    BMKCoordinateRegion region;
    region.center.latitude = userLocation.location.coordinate.latitude;
    region.center.longitude = userLocation.location.coordinate.longitude;
    region.span.latitudeDelta = 0.2;
    region.span.longitudeDelta = 0.2;
    _mapView.region = region;

    [_mapView updateLocationData:userLocation];
}

/**
 *在地图View停止定位后，会调用此函数
 *@param mapView 地图View
 */
- (void)didStopLocatingUser
{
    NSLog(@"stop locate");
}

/**
 *定位失败后，会调用此函数
 *@param mapView 地图View
 *@param error 错误号，参考CLError.h中定义的错误号
 */
- (void)didFailToLocateUserWithError:(NSError *)error
{
    NSLog(@"location error");
}

#pragma mark -- 查询并返回圆形区域内的所有合法对象 11-13
/**
 *计算指定两点之间的距离
 *@param a 第一个坐标点
 *@param b 第二个坐标点
 *@return 两点之间的距离，单位：米
 
UIKIT_EXTERN CLLocationDistance BMKMetersBetweenMapPoints(BMKMapPoint a, BMKMapPoint b);
 
 @param annotation 为标注对象
 @param array 存放标注的数组 _locationAry
 **/
-(NSMutableArray *)centerForsearchthird:(id)annotation radiusForsearch:(float)radius searchTotarget:(NSArray *)array{
    
    NSMutableArray *resultAry = [[NSMutableArray alloc] init];
    CLLocationCoordinate2D coor;
    if ([annotation isKindOfClass:[BMKPointAnnotation class]]) {
        BMKPointAnnotation *PAtation = annotation;
        coor = PAtation.coordinate;
    }else if([annotation isKindOfClass:[CustomAnnotation class]]){
        CustomAnnotation *CustAtation = annotation;
        coor = CustAtation.coordinate;
    }
    //设置中心点pcenter;
    BMKMapPoint pcenter = BMKMapPointForCoordinate(coor);
    for (id object in array) {
        
        CLLocationCoordinate2D targetcoor;//目标坐标
        
        if ([object isKindOfClass:[BMKPointAnnotation class]]) {
            BMKPointAnnotation *pannotation = object;
            targetcoor.latitude = pannotation.coordinate.latitude;
            targetcoor.longitude = pannotation.coordinate.longitude;
            
        } else if([object isKindOfClass:[CustomAnnotation class]]){
            CustomAnnotation *cusannotation = object;
            targetcoor.latitude = cusannotation.coordinate.latitude;
            targetcoor.longitude = cusannotation.coordinate.longitude;
        }
        

        BMKMapPoint ptarget = BMKMapPointForCoordinate(targetcoor);
        //计算地图上两点之间的距离
        CLLocationDistance dis = BMKMetersBetweenMapPoints(pcenter, ptarget);
        if (dis <= radius) {
            [resultAry addObject:object];
        }
    }
    
    return resultAry;
}


#pragma mark -- 返回一个正方形的区域内的所有符合对象 //传入标注数组，_locationAry;
/**
 *根据中心点和距离生成BMKCoordinateRegion
 *@param centerCoordinate 中心点坐标
 *@param latitudinalMeters 纬度方向的距离范围，单位：米
 *@param longitudinalMeters 经度方向的距离范围，单位：米
 *@return 根据中心点和距离生成BMKCoordinateRegion
 
  UIKIT_EXTERN BMKCoordinateRegion BMKCoordinateRegionMakeWithDistance(CLLocationCoordinate2D centerCoordinate, CLLocationDistance latitudinalMeters, CLLocationDistance longitudinalMeters);

 @param id 为任意对象
 @param array 存放标注 对象的数组 _locationAry;
 **/
-(NSMutableArray *)searchForcenterSecond:(id)annotation radiusForsearch:(float)radius searchTotarget:(NSArray *)array{
    
    NSMutableArray *resultAry = [[NSMutableArray alloc] init];
    CLLocationCoordinate2D coor;
    if ([annotation isKindOfClass:[BMKPointAnnotation class]]) {
        BMKPointAnnotation *PAtation = annotation;
        coor = PAtation.coordinate;
    }else if([annotation isKindOfClass:[CustomAnnotation class]]){
        CustomAnnotation *CustAtation = annotation;
        coor = CustAtation.coordinate;
    }
    float customRadius = 1.0 * radius / sqrt(2);
    BMKCoordinateRegion region = BMKCoordinateRegionMakeWithDistance(coor, customRadius, customRadius);
    
    BOOL FirstJuge = nil;
    BOOL SecondJuge = nil;
    for (id object in array) {
        
        if ([object isKindOfClass:[BMKPointAnnotation class]]) {
            BMKPointAnnotation *pannotation = object;
            //绝对值，测算目标与中心点的经、纬度差值是否在波动范围内
            FirstJuge = (fabs(pannotation.coordinate.latitude - coor.latitude) <= region.span.latitudeDelta);
            SecondJuge = (fabs(pannotation.coordinate.longitude - coor.longitude) <= region.span.longitudeDelta);
            
        } else if ([object isKindOfClass:[CustomAnnotation class]]){
            CustomAnnotation *Cusannotation = object;
            FirstJuge = (fabs(Cusannotation.coordinate.latitude - coor.latitude) <= region.span.latitudeDelta);
            SecondJuge = (fabs(Cusannotation.coordinate.longitude - coor.longitude) <= region.span.longitudeDelta);
        }
        
        //经纬度波动范围同时满足条件时，将对象加入数组并返回
        if (FirstJuge && SecondJuge) {
            [resultAry addObject:object];
        }
    }
    return resultAry;
}

@end
