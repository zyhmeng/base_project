//
//  DetailController.h
//  YunfengDemo
//
//  Created by Hudasen on 15/11/11.
//  Copyright © 2015年 Hudasen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailController : UIViewController

@property(nonatomic,assign)float DetailLatitude;
@property(nonatomic,assign)float DetailLongitude;

@end
