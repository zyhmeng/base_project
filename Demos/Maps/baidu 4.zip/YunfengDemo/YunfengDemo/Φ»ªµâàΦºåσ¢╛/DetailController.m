//
//  DetailController.m
//  YunfengDemo
//
//  Created by Hudasen on 15/11/11.
//  Copyright © 2015年 Hudasen. All rights reserved.
//

#import "DetailController.h"

@interface DetailController ()

@end

@implementation DetailController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = CGRectMake(10, 100, 60, 60);
    button.backgroundColor = [UIColor grayColor];
    [self.view addSubview:button];
    [button addTarget:self action:@selector(tuichu:) forControlEvents:UIControlEventTouchUpInside];
    NSLog(@"xxxx%f xxxx%f",_DetailLatitude,_DetailLongitude);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)tuichu:(UIButton *)button{
    [self dismissViewControllerAnimated:YES completion:nil];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
