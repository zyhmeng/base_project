//
//  CustomAnnotation.m
//  YunfengDemo
//
//  Created by Hudasen on 15/11/12.
//  Copyright © 2015年 Hudasen. All rights reserved.
//

#import "CustomAnnotation.h"

@implementation CustomAnnotation

-(CLLocationCoordinate2D)coordinate{
    return self.myCoordinate;
}


@end
