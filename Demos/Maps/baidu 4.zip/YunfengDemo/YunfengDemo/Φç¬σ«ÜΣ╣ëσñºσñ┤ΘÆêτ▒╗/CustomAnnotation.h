//
//  CustomAnnotation.h
//  YunfengDemo
//
//  Created by Hudasen on 15/11/12.
//  Copyright © 2015年 Hudasen. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <BaiduMapAPI_Map/BMKAnnotation.h>
@interface CustomAnnotation : NSObject<BMKAnnotation>

@property(nonatomic)CLLocationCoordinate2D myCoordinate;

@property(nonatomic,copy)NSString *myTitle;

@property(nonatomic,copy)NSString *imagename;

@property(nonatomic,copy)NSString *content;

@end
