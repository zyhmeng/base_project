//
//  myModel.m
//  YunfengDemo
//
//  Created by Hudasen on 15/11/11.
//  Copyright © 2015年 Hudasen. All rights reserved.
//

#import "myModel.h"

@implementation myModel

@end
