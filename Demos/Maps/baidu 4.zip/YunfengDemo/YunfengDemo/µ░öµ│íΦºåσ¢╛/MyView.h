//
//  MyView.h
//  YunfengDemo
//
//  Created by Hudasen on 15/11/11.
//  Copyright © 2015年 Hudasen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyView : UIView

@property(nonatomic,assign)float la;

@property(nonatomic,assign)float lon;

@property(nonatomic,strong)UIImageView *image;
@property(nonatomic,strong)UILabel *nameLabel;
@property(nonatomic,strong)UILabel *yewuLabel;

@end
