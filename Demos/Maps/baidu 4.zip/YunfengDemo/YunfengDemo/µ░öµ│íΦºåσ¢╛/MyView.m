//
//  MyView.m
//  YunfengDemo
//
//  Created by Hudasen on 15/11/11.
//  Copyright © 2015年 Hudasen. All rights reserved.
//

#import "MyView.h"

@implementation MyView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
