//
//  SerialLocationViewController.h
//  officialDemoLoc
//
//  Created by 刘博 on 15/9/21.
//  Copyright © 2015年 AutoNavi. All rights reserved.
//

#import "BaseMapViewController.h"

@interface SerialLocationViewController : BaseMapViewController

@end
