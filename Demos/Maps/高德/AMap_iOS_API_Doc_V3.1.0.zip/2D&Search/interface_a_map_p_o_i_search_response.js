var interface_a_map_p_o_i_search_response =
[
    [ "count", "interface_a_map_p_o_i_search_response.html#a05f0afb367d695003d9ac4ea178b0093", null ],
    [ "pois", "interface_a_map_p_o_i_search_response.html#ae271768bd59f9d511331a202cd3a7bdc", null ],
    [ "suggestion", "interface_a_map_p_o_i_search_response.html#ac79cdd74712e1650968931464d757e87", null ]
];