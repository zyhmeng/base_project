var interface_a_map_bus_stop_search_response =
[
    [ "busstops", "interface_a_map_bus_stop_search_response.html#a0609506d82acbb5060f1aaea2f14156e", null ],
    [ "count", "interface_a_map_bus_stop_search_response.html#a576534eea3d06cef40cc8f4e7888e494", null ],
    [ "suggestion", "interface_a_map_bus_stop_search_response.html#a8b745e2444c66b26ac10358af398d621", null ]
];