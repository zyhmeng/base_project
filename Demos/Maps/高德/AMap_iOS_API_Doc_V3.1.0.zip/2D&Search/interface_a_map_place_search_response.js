var interface_a_map_place_search_response =
[
    [ "count", "interface_a_map_place_search_response.html#ab2deea27eb5924af62a3b16e23f46aca", null ],
    [ "pois", "interface_a_map_place_search_response.html#a2a31a38b2b965738d30a9bb722b222d7", null ],
    [ "suggestion", "interface_a_map_place_search_response.html#a68b508a4fb5cc061910e7ad01ac277a2", null ]
];