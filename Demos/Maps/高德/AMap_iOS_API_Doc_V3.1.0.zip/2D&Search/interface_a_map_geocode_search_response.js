var interface_a_map_geocode_search_response =
[
    [ "count", "interface_a_map_geocode_search_response.html#a99eced1a4d58bff33e97a75de4b182dd", null ],
    [ "geocodes", "interface_a_map_geocode_search_response.html#a85ac8d093a3b33f96dab5eb41e616155", null ]
];