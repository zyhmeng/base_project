var searchData=
[
  ['uid',['uid',['../interface_a_map_tip.html#acca377dc638cdb6ecb1294337cf92c8f',1,'AMapTip::uid()'],['../interface_a_map_p_o_i.html#a07852d7ea37cbbe450d5c79353f6d04d',1,'AMapPOI::uid()'],['../interface_a_map_road.html#a3650062b06bdfd588fb416ce8af831c0',1,'AMapRoad::uid()'],['../interface_a_map_bus_stop.html#a6589bffca062864784e0685e12be1f8f',1,'AMapBusStop::uid()'],['../interface_a_map_bus_line.html#aac351ce7c292ac9df46f9676b428ea3d',1,'AMapBusLine::uid()'],['../interface_a_map_p_o_i_i_d_search_request.html#ab4a66e1d896616726ebce450fa963260',1,'AMapPOIIDSearchRequest::uid()'],['../interface_a_map_bus_line_i_d_search_request.html#a710113d7574fd59494acf37ee9adcb11',1,'AMapBusLineIDSearchRequest::uid()']]],
  ['updatetime',['updatetime',['../interface_a_map_nearby_user_info.html#a4d752681d40f0f7bcae1d484f43055e5',1,'AMapNearbyUserInfo']]],
  ['updateuserlocationrepresentation_3a',['updateUserLocationRepresentation:',['../interface_m_a_map_view.html#a94d150e96a592798b0558d4423422cce',1,'MAMapView']]],
  ['updating',['updating',['../interface_m_a_user_location.html#af8ed215143761b9811234196549da8f6',1,'MAUserLocation']]],
  ['uploadnearbyinfo_3a',['uploadNearbyInfo:',['../interface_a_map_nearby_search_manager.html#ab258e06250413c9d56e6568279cf06be',1,'AMapNearbySearchManager']]],
  ['uploadtimeinterval',['uploadTimeInterval',['../interface_a_map_nearby_search_manager.html#a483261c024ac346148c38c72c235fd2f',1,'AMapNearbySearchManager']]],
  ['urlfortilepath_3a',['URLForTilePath:',['../category_m_a_tile_overlay_07_custom_loading_08.html#aacc5d904fedafb39cc635c042fa56599',1,'MATileOverlay(CustomLoading)::URLForTilePath:()'],['../interface_m_a_tile_overlay.html#aacc5d904fedafb39cc635c042fa56599',1,'MATileOverlay::URLForTilePath:()']]],
  ['urltemplate',['URLTemplate',['../interface_m_a_tile_overlay.html#aaff14d9c454fae49ccf6b5d6160e9831',1,'MATileOverlay']]],
  ['userid',['userID',['../interface_a_map_nearby_user_info.html#a3e2a3684eed555835d8528f658494f8d',1,'AMapNearbyUserInfo::userID()'],['../interface_a_map_nearby_upload_info.html#a56c8705b5ad00affa621337411cc77f1',1,'AMapNearbyUploadInfo::userID()']]],
  ['userlocation',['userLocation',['../interface_m_a_map_view.html#ad4b091fc74c739f0364ceb30c7f0b357',1,'MAMapView']]],
  ['userlocationvisible',['userLocationVisible',['../interface_m_a_map_view.html#ab7829e4d640abdea70365974cdd36dfe',1,'MAMapView']]],
  ['usertrackingmode',['userTrackingMode',['../interface_m_a_map_view.html#a5ec6f96c702ee35ad5199d5604d243e8',1,'MAMapView']]]
];
