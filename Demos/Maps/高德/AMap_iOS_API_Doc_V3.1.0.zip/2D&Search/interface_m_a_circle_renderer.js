var interface_m_a_circle_renderer =
[
    [ "initWithCircle:", "interface_m_a_circle_renderer.html#aee30b1321bc101a776034fb8e1bb31e9", null ],
    [ "circle", "interface_m_a_circle_renderer.html#ad97e2ccacd48360d221ab156880b3331", null ]
];