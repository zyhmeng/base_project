var interface_m_a_heat_map_node =
[
    [ "coordinate", "interface_m_a_heat_map_node.html#a3001789a8e348a8b0b1971efb7bd2145", null ],
    [ "intensity", "interface_m_a_heat_map_node.html#a004eb83d9a650bccc428407013592530", null ]
];