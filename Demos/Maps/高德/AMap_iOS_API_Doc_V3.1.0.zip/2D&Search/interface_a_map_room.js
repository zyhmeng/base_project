var interface_a_map_room =
[
    [ "breakfast", "interface_a_map_room.html#a4093903d5516946c9818e2f801de8835", null ],
    [ "guarantee", "interface_a_map_room.html#a12d49d7e2a50ce4c2f78fe49168674b5", null ],
    [ "name", "interface_a_map_room.html#a56c4aae8226a62cd87244909f43c393c", null ],
    [ "network", "interface_a_map_room.html#afb46f93c9ebb2ce71e81e39e986703ba", null ],
    [ "orderingUrlWap", "interface_a_map_room.html#a1a39d7f919b17183c4a5457760e95585", null ],
    [ "orderingUrlWeb", "interface_a_map_room.html#a05e9d3fd9d90287b4b36b03fec3808fd", null ],
    [ "price", "interface_a_map_room.html#a19c63c012b91c6e5c749d6113e524d47", null ],
    [ "provider", "interface_a_map_room.html#a7f03d08c567bd1aeddd055d43cdeacb6", null ],
    [ "tel", "interface_a_map_room.html#a259e4661bc74e324fad6a4c1e066d23e", null ],
    [ "type", "interface_a_map_room.html#a23c01d0129be4b0fe3d9e555ba80e8e8", null ],
    [ "uid", "interface_a_map_room.html#a6b3648c4f5db5ec848aa1e5234cc1329", null ]
];