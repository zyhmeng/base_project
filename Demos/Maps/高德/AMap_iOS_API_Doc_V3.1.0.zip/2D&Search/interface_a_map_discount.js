var interface_a_map_discount =
[
    [ "detail", "interface_a_map_discount.html#ad29356bd5af008e08cb861465b916305", null ],
    [ "endTime", "interface_a_map_discount.html#a726ebb6042a6f0d30a887cddd903ffc5", null ],
    [ "photos", "interface_a_map_discount.html#a990d98cb26f7a9541338802fc2abad44", null ],
    [ "provider", "interface_a_map_discount.html#a4754a2f9e2bf814a3a441046f4b7e16b", null ],
    [ "soldNum", "interface_a_map_discount.html#a73a5c08f79ad458568842f0e7f139ce6", null ],
    [ "startTime", "interface_a_map_discount.html#a1482f9bc9878e2e5ddb259474cf97ed2", null ],
    [ "title", "interface_a_map_discount.html#aaf87a686653657526992b925dcadf44e", null ],
    [ "url", "interface_a_map_discount.html#a61bd38dbf3395b8cc7e2fcdd91ff1999", null ]
];