var interface_a_map_dining_deep_content =
[
    [ "addition", "interface_a_map_dining_deep_content.html#ab01da0dd96ab0e507a695ff3733949f2", null ],
    [ "appUrl", "interface_a_map_dining_deep_content.html#a15701577bc47da6a37aee2a9fa4fe336", null ],
    [ "atmosphere", "interface_a_map_dining_deep_content.html#aba4025beca5cfbe87e16003564c98732", null ],
    [ "cost", "interface_a_map_dining_deep_content.html#a733542ec9145ec478bc19dcbffc6ced0", null ],
    [ "cpRating", "interface_a_map_dining_deep_content.html#a0d866c9b5eb2ac6c4b2f75a09775c5f7", null ],
    [ "cuisines", "interface_a_map_dining_deep_content.html#a9359a7a073fa3feeda04ae47bd359b17", null ],
    [ "environmentRating", "interface_a_map_dining_deep_content.html#a8121464a2baca92b10dff2dbcfb93389", null ],
    [ "opentime", "interface_a_map_dining_deep_content.html#a29bec7f845dd7072e3b9d7654ac1e81b", null ],
    [ "opentimeGDF", "interface_a_map_dining_deep_content.html#a1fe1f1effc71c1f8065ad9c65c3ee232", null ],
    [ "orderingUrlWap", "interface_a_map_dining_deep_content.html#a6f30e1d93d44f85e38864391ba06d558", null ],
    [ "orderingUrlWeb", "interface_a_map_dining_deep_content.html#ad56c8d8c09c7b46c9059407ea7c0ce48", null ],
    [ "recommend", "interface_a_map_dining_deep_content.html#a276bc5fdda44ee3bb966330ffafd1cca", null ],
    [ "serviceRating", "interface_a_map_dining_deep_content.html#abad51dcf2eb7458b6b67febef7408502", null ],
    [ "tag", "interface_a_map_dining_deep_content.html#a8fdeaa8ad2be269570080e4bffdabc4b", null ],
    [ "tasteRating", "interface_a_map_dining_deep_content.html#af5dd7ef948a35f438679996da08043c1", null ]
];