var interface_a_map_input_tips_search_request =
[
    [ "city", "interface_a_map_input_tips_search_request.html#a0e49f4225dc3d9a5af5c7c704890460b", null ],
    [ "keywords", "interface_a_map_input_tips_search_request.html#a34eeecd5938946579b7d8841d3249529", null ]
];