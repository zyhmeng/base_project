var interface_a_map_road =
[
    [ "direction", "interface_a_map_road.html#ae323c8221a83b905b2cb9dc5d59d2b4d", null ],
    [ "distance", "interface_a_map_road.html#a2f18016a16a48c150b10da4e0ad2de4c", null ],
    [ "location", "interface_a_map_road.html#a065117a9d8b4aa51ac883dc2f64941ba", null ],
    [ "name", "interface_a_map_road.html#ae662b7ee5469fd8a02b6745dfd6aff9c", null ],
    [ "uid", "interface_a_map_road.html#a3650062b06bdfd588fb416ce8af831c0", null ]
];