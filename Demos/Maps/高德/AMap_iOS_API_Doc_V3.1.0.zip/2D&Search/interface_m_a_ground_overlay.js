var interface_m_a_ground_overlay =
[
    [ "bounds", "interface_m_a_ground_overlay.html#aedb61b591a8c4f53590df4611cd96881", null ],
    [ "icon", "interface_m_a_ground_overlay.html#a16cc9e834f8111c525c724282f09af04", null ],
    [ "zoomLevel", "interface_m_a_ground_overlay.html#a594f0473b7ff494110ac51e4121496f8", null ]
];