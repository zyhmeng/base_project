var interface_m_a_p_o_i_config =
[
    [ "appName", "interface_m_a_p_o_i_config.html#a6d28e7fd3e3f21817cbf5ffa67740abb", null ],
    [ "appScheme", "interface_m_a_p_o_i_config.html#a2c6753874c8db8a2c6e6a1ace2db44a5", null ],
    [ "keywords", "interface_m_a_p_o_i_config.html#a9ab4d8c611a9c05f727d1fe5e84d55c0", null ],
    [ "leftTopCoordinate", "interface_m_a_p_o_i_config.html#a1e60feef905dd982825e1c6936f9413e", null ],
    [ "rightBottomCoordinate", "interface_m_a_p_o_i_config.html#a14fa391860c69d6a0a9668e57c1d7774", null ]
];