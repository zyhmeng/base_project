var interface_a_map_place_search_request =
[
    [ "city", "interface_a_map_place_search_request.html#a6f7a57d140ad325ba1da2b266c3b9a62", null ],
    [ "keywords", "interface_a_map_place_search_request.html#a679c321dba77781efb03ecf86f0e65c8", null ],
    [ "location", "interface_a_map_place_search_request.html#a0747b8ea71c3888bddaf00a85a7079c4", null ],
    [ "offset", "interface_a_map_place_search_request.html#a5c362a3f9b894c44f4716f0e185e896d", null ],
    [ "page", "interface_a_map_place_search_request.html#aee6ab484b833bca922c1de4db2c9d9c6", null ],
    [ "polygon", "interface_a_map_place_search_request.html#ac27ab25349a717aa4b3db258e2c4617a", null ],
    [ "radius", "interface_a_map_place_search_request.html#ae061912ee075b09cc6099ee342e6a6dc", null ],
    [ "requireDiscount", "interface_a_map_place_search_request.html#a6ef75b37965556335b54f7deb8755c21", null ],
    [ "requireExtension", "interface_a_map_place_search_request.html#ad2bda2d3e1d837a06dec7d95fb044982", null ],
    [ "requireGroup", "interface_a_map_place_search_request.html#a19cff70bbecb20234e7f9988f64b3c0d", null ],
    [ "searchFilter", "interface_a_map_place_search_request.html#a326091d81b0efed647885572f7049f7b", null ],
    [ "searchType", "interface_a_map_place_search_request.html#a9ff0b02bc4d442318c8dfeb52958bdb0", null ],
    [ "sortrule", "interface_a_map_place_search_request.html#ad8157c40e6ad3fd56a88cf46d45f61eb", null ],
    [ "types", "interface_a_map_place_search_request.html#a8fde980054b3ec54d5da6394fb50acae", null ],
    [ "uid", "interface_a_map_place_search_request.html#ae10d4afb05e92f21049cbac6971ba4e6", null ]
];