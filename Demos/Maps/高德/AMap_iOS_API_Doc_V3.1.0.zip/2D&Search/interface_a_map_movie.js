var interface_a_map_movie =
[
    [ "actors", "interface_a_map_movie.html#ad80a6a120a9a18f06986e5062492cea8", null ],
    [ "director", "interface_a_map_movie.html#a3da539b4f5f411185abebb5d393844d5", null ],
    [ "length", "interface_a_map_movie.html#a998e18a4fc8c8d33ac971966497ca171", null ],
    [ "name", "interface_a_map_movie.html#aff2a7c90c0f9cd76732f2a571e819210", null ],
    [ "tickets", "interface_a_map_movie.html#a8286099c73bf1aaad9600cf2041b79de", null ],
    [ "type", "interface_a_map_movie.html#a36d2201c4223922df1646acf542c30a3", null ],
    [ "uid", "interface_a_map_movie.html#a892aea63cf7e7207661abf6efc206aad", null ]
];