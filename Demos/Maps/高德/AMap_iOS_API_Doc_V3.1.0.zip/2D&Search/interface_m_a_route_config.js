var interface_m_a_route_config =
[
    [ "appName", "interface_m_a_route_config.html#a9c79803292d93f485bf75b201188a074", null ],
    [ "appScheme", "interface_m_a_route_config.html#a82bc99d2eb163d9abd77eb309dabbbf3", null ],
    [ "destinationCoordinate", "interface_m_a_route_config.html#a38ce54186b84627a8d0c2766396ac690", null ],
    [ "drivingStrategy", "interface_m_a_route_config.html#af4a62706a128958a4b72f8904b2259bf", null ],
    [ "routeType", "interface_m_a_route_config.html#a0efcfb94773166e0885ab7aab988273d", null ],
    [ "startCoordinate", "interface_m_a_route_config.html#a5c890d4296ffdc2cc9d84d58d17962e7", null ],
    [ "transitStrategy", "interface_m_a_route_config.html#a82e472587ccd3eb3301332b8ca850b92", null ]
];