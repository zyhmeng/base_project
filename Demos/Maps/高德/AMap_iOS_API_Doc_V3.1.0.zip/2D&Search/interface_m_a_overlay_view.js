var interface_m_a_overlay_view =
[
    [ "canDrawMapRect:zoomScale:", "interface_m_a_overlay_view.html#a41645d14567c73ace16be819745482b7", null ],
    [ "drawMapRect:zoomScale:inContext:", "interface_m_a_overlay_view.html#a14b2dea20190fdf2c0bff6efb53d6df3", null ],
    [ "initWithOverlay:", "interface_m_a_overlay_view.html#a474ca3295e96f72003798aae7889650a", null ],
    [ "mapPointForPoint:", "interface_m_a_overlay_view.html#afc445798826f8607a9d2d4e87406022a", null ],
    [ "mapRectForRect:", "interface_m_a_overlay_view.html#a4116373694e9c1574020d8cdfe3e32dd", null ],
    [ "pointForMapPoint:", "interface_m_a_overlay_view.html#a84412c9066ceb6d0d62a8be62e74833c", null ],
    [ "rectForMapRect:", "interface_m_a_overlay_view.html#af30d3dc8093c7910daad0a24d865fdc8", null ],
    [ "setNeedsDisplay", "interface_m_a_overlay_view.html#a9e1d75ab2ab03aada50a6f8a5c79ff5d", null ],
    [ "setNeedsDisplayInMapRect:", "interface_m_a_overlay_view.html#a0f0827a2bbcb5d0de9ec5def04affe2d", null ],
    [ "setNeedsDisplayInMapRect:zoomScale:", "interface_m_a_overlay_view.html#ae6a8912a6a4f3d1d3a44eb11d43c376a", null ],
    [ "alpha", "interface_m_a_overlay_view.html#aa80b16a76349c401c8752072c3a61307", null ],
    [ "contentScaleFactor", "interface_m_a_overlay_view.html#a3061e177c61aa1c443413aa795695cfc", null ],
    [ "overlay", "interface_m_a_overlay_view.html#aa2d324d3771d9209ce8b9d73053b6e12", null ]
];