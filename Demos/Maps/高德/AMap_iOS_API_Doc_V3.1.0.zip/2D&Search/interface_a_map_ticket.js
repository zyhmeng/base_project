var interface_a_map_ticket =
[
    [ "lang", "interface_a_map_ticket.html#a04f995d7d67e130895c91f1be93662b7", null ],
    [ "orderingUrlWap", "interface_a_map_ticket.html#aed4a541bfeb526409594ca48db0e3511", null ],
    [ "orderingUrlWeb", "interface_a_map_ticket.html#af7e255dbcb43357db12b16e13ddc5421", null ],
    [ "price", "interface_a_map_ticket.html#a36fa576426f0ed408d4f37c27a22d7e6", null ],
    [ "screen", "interface_a_map_ticket.html#ad6690587b855221f1611ad99dc582592", null ],
    [ "seatOrdering", "interface_a_map_ticket.html#a225ccd63b7872af2b69d04b2f864d9b6", null ],
    [ "startTime", "interface_a_map_ticket.html#a46037c67cd4957c0c1d007a553c5b11e", null ]
];