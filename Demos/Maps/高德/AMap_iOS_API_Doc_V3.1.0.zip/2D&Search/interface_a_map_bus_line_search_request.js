var interface_a_map_bus_line_search_request =
[
    [ "city", "interface_a_map_bus_line_search_request.html#ab60dd847f562d4552ef7505bd636891b", null ],
    [ "keywords", "interface_a_map_bus_line_search_request.html#adf9325670dcb2918f1e1c330628a6c7b", null ],
    [ "offset", "interface_a_map_bus_line_search_request.html#a68b7e7b4f496ab8bcb1ef694e90a9002", null ],
    [ "page", "interface_a_map_bus_line_search_request.html#a17d7b0766dfc929b04cf5d00e4699821", null ],
    [ "requireExtension", "interface_a_map_bus_line_search_request.html#a6946f211ce2b554f32473437685e6db2", null ],
    [ "searchType", "interface_a_map_bus_line_search_request.html#ae664a801135a3e6b77ee6b197ab7174f", null ],
    [ "uid", "interface_a_map_bus_line_search_request.html#a600556641acc907167f9ed14b719ee36", null ]
];