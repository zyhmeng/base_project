var interface_a_map_segment =
[
    [ "buslines", "interface_a_map_segment.html#a86dddcb255501800e9a6b67054159aaa", null ],
    [ "enterLocation", "interface_a_map_segment.html#acb7b364d36e4023ca7789ce0abd69d8b", null ],
    [ "enterName", "interface_a_map_segment.html#afafd0edb58fbbe1e248e000147bf7afa", null ],
    [ "exitLocation", "interface_a_map_segment.html#a865dd34f7ef1693536cd50196ae159a2", null ],
    [ "exitName", "interface_a_map_segment.html#a172de8156b2eef10c5f303769aeb587a", null ],
    [ "walking", "interface_a_map_segment.html#ac7cc248ef42b0f4e3f32f9340c2f9596", null ]
];