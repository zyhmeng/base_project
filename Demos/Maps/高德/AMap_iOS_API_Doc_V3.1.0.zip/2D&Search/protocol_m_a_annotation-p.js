var protocol_m_a_annotation_p =
[
    [ "setCoordinate:", "protocol_m_a_annotation-p.html#aad23f4cf973e5d69185ee75d426039ee", null ],
    [ "coordinate", "protocol_m_a_annotation-p.html#a789ed522a37913789847b7842c3bc9c4", null ],
    [ "subtitle", "protocol_m_a_annotation-p.html#a0688db416bcfd1d92980981e2783ee2d", null ],
    [ "title", "protocol_m_a_annotation-p.html#a7f68a56e8558662e027d1c498ebb3d5e", null ]
];