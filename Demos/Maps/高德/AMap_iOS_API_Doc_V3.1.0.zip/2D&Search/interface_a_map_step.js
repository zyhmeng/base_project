var interface_a_map_step =
[
    [ "action", "interface_a_map_step.html#ab78d8a10ee4c953bee65ac029d9519c5", null ],
    [ "assistantAction", "interface_a_map_step.html#acdd7a426063461258b6db2216e0c725c", null ],
    [ "cities", "interface_a_map_step.html#aeddcc6b326229570283fa4bd9245d51e", null ],
    [ "distance", "interface_a_map_step.html#a9a5cf75fd92ef40b14640131465922f7", null ],
    [ "duration", "interface_a_map_step.html#aa0bedda4995b7a026dd234e7b338359a", null ],
    [ "instruction", "interface_a_map_step.html#ade98c180f08b39112936eaa121e1d330", null ],
    [ "orientation", "interface_a_map_step.html#a1282b15ec891687315bc59bbc398a1e4", null ],
    [ "polyline", "interface_a_map_step.html#a9ea1b4437d09d967a2aefe6ca3ddad31", null ],
    [ "road", "interface_a_map_step.html#a1b3a15620ef8589e381eeb4fbf8921ae", null ],
    [ "tollDistance", "interface_a_map_step.html#a927b0575da3a142870cb060dc4cd1e7c", null ],
    [ "tollRoad", "interface_a_map_step.html#a801a5933f40803e3570c328e6e0822d2", null ],
    [ "tolls", "interface_a_map_step.html#a650ab328fb696bcc2534fd5f5bd25f19", null ]
];