var interface_a_map_local_weather_forecast =
[
    [ "adcode", "interface_a_map_local_weather_forecast.html#aad976e0daa42da5445cbdca61b95c216", null ],
    [ "casts", "interface_a_map_local_weather_forecast.html#a63e774250f661fe0f915b7f270e6856c", null ],
    [ "city", "interface_a_map_local_weather_forecast.html#ad7c0a50f7ed2d9b5484f7579a22cda14", null ],
    [ "province", "interface_a_map_local_weather_forecast.html#aa78aa06bff2e9f4d75865b39ce941c7e", null ],
    [ "reportTime", "interface_a_map_local_weather_forecast.html#a007d089608404fc2c2560ae4e0af257c", null ]
];