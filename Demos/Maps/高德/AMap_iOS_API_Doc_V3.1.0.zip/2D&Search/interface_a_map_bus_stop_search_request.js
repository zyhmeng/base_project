var interface_a_map_bus_stop_search_request =
[
    [ "city", "interface_a_map_bus_stop_search_request.html#a83de65538caa4f576fb88e3a3e988ba8", null ],
    [ "keywords", "interface_a_map_bus_stop_search_request.html#affd78983bfd59e77e935c572b89987e8", null ],
    [ "offset", "interface_a_map_bus_stop_search_request.html#aac7a1fe94e1f5b22d3782b9fd548e71c", null ],
    [ "page", "interface_a_map_bus_stop_search_request.html#afaea21dc9e10bfc297c6158ba24a8004", null ]
];