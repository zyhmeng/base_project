var interface_a_map_district =
[
    [ "adcode", "interface_a_map_district.html#a92426b2220e9122546ad74aa31900722", null ],
    [ "center", "interface_a_map_district.html#a3563a1b8c452876c64522540eca12c22", null ],
    [ "citycode", "interface_a_map_district.html#a464ee88d82ef3ccac13cd8a561b15158", null ],
    [ "districts", "interface_a_map_district.html#a307916d4512c06001cf9b9038074f125", null ],
    [ "level", "interface_a_map_district.html#ac2250b73c88626f9c0c450940f3f6429", null ],
    [ "name", "interface_a_map_district.html#a6c766d678b5022b22508cf1481730138", null ],
    [ "polylines", "interface_a_map_district.html#af85d1409705570e39e0876f890ee2de4", null ]
];