var protocol_a_map_nearby_search_manager_delegate_p =
[
    [ "nearbyInfoForUploading:", "protocol_a_map_nearby_search_manager_delegate-p.html#a80dd67dbda25b825abdb95df7eaa7d2c", null ],
    [ "onNearbyInfoUploadedWithError:", "protocol_a_map_nearby_search_manager_delegate-p.html#a174ef4b1efed7191b2de1932527b5141", null ],
    [ "onUserInfoClearedWithError:", "protocol_a_map_nearby_search_manager_delegate-p.html#a7ad3f7b4ce6f3c0ab66559fddc2e9db9", null ]
];