var protocol_a_map_search_delegate_p =
[
    [ "AMapSearchRequest:didFailWithError:", "protocol_a_map_search_delegate-p.html#a63b18609b7c4526dca4d83ffdf0a4b4c", null ],
    [ "onBusLineSearchDone:response:", "protocol_a_map_search_delegate-p.html#a4113daf3d0634661b4d00fb7f384d7ed", null ],
    [ "onBusStopSearchDone:response:", "protocol_a_map_search_delegate-p.html#af90a721d370e4de4df57b46890011d3b", null ],
    [ "onDistrictSearchDone:response:", "protocol_a_map_search_delegate-p.html#aa8574062481da5b94ae3b77fec276085", null ],
    [ "onGeocodeSearchDone:response:", "protocol_a_map_search_delegate-p.html#a5d30cc6b574e50d0797b98b058d0b764", null ],
    [ "onInputTipsSearchDone:response:", "protocol_a_map_search_delegate-p.html#a72a41043ca8ae09caa63289ea5237012", null ],
    [ "onNearbySearchDone:response:", "protocol_a_map_search_delegate-p.html#aabf1df677162cd2f9f4e86e305b1609d", null ],
    [ "onPOISearchDone:response:", "protocol_a_map_search_delegate-p.html#a6ec305203c772d6a72b801146ed145ca", null ],
    [ "onReGeocodeSearchDone:response:", "protocol_a_map_search_delegate-p.html#a9985fe475c78fcb235777acf3188cb2f", null ],
    [ "onRouteSearchDone:response:", "protocol_a_map_search_delegate-p.html#a9cad0437266104db86940e1f8a6f882a", null ],
    [ "onWeatherSearchDone:response:", "protocol_a_map_search_delegate-p.html#a55fe38b885a5e9c80f296dc2a9d5694a", null ]
];