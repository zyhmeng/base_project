var interface_a_map_search_services =
[
    [ "apiKey", "interface_a_map_search_services.html#a1a7f6a7b3e71b5a30a8af04419a162ed", null ],
    [ "SDKVersion", "interface_a_map_search_services.html#ada9b56fc22e75fdc3ceca8e3d632a9b3", null ]
];