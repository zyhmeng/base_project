var interface_a_map_geocode_search_request =
[
    [ "address", "interface_a_map_geocode_search_request.html#a71b9e065768b490828bccb95eb57eade", null ],
    [ "city", "interface_a_map_geocode_search_request.html#ab0d2dededc91e03f8fda33e151b04a63", null ]
];