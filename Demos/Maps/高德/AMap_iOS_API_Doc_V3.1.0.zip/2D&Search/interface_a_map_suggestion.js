var interface_a_map_suggestion =
[
    [ "cities", "interface_a_map_suggestion.html#a2b6cbf14bc1a80590f0e7e35212f3d80", null ],
    [ "keywords", "interface_a_map_suggestion.html#aa42fc012c61a9e5ae6f3227e7a2b75ab", null ]
];