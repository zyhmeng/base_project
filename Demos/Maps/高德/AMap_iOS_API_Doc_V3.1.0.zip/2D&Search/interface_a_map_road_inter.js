var interface_a_map_road_inter =
[
    [ "direction", "interface_a_map_road_inter.html#ae997ee65a07ac8b79748ed279b1c2b73", null ],
    [ "distance", "interface_a_map_road_inter.html#a3158c352710bfdd7fea8a6d342803c36", null ],
    [ "firstId", "interface_a_map_road_inter.html#a23a986bffa64759e49bd2e7bec2b5fbc", null ],
    [ "firstName", "interface_a_map_road_inter.html#a72b86c5e278b077694326b8e212bf500", null ],
    [ "location", "interface_a_map_road_inter.html#aef89806d1acf442780697ef383de5b9e", null ],
    [ "secondId", "interface_a_map_road_inter.html#a21b9fc14344d52c149779bd4433adbbe", null ],
    [ "secondName", "interface_a_map_road_inter.html#ae0402df33b4e785199c5708f22f02cea", null ]
];