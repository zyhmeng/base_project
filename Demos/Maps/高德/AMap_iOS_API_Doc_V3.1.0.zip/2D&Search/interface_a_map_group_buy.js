var interface_a_map_group_buy =
[
    [ "detail", "interface_a_map_group_buy.html#ae43ecf78cb8cdf0d67277b7938ee2383", null ],
    [ "discount", "interface_a_map_group_buy.html#a5f2a7a85addf763c0f887e5fbf9d4a20", null ],
    [ "endTime", "interface_a_map_group_buy.html#a4316bf9813702d3c1d5328a8a445e041", null ],
    [ "groupbuyPrice", "interface_a_map_group_buy.html#af94d109678406cfd87b61ee242cbe838", null ],
    [ "num", "interface_a_map_group_buy.html#a359e3f2e90077ab8bb83c39a4af2e8e7", null ],
    [ "originalPrice", "interface_a_map_group_buy.html#acd62e46b6a3bc3386b0f7f2a64cbd5b0", null ],
    [ "photos", "interface_a_map_group_buy.html#a6dd9a85ba26cebf961ee30d98f8f3c0d", null ],
    [ "provider", "interface_a_map_group_buy.html#a9159e1103304ba1590fea16895896ce1", null ],
    [ "soldNum", "interface_a_map_group_buy.html#a4f01be222ff24fcb5c4014c4335b8224", null ],
    [ "startTime", "interface_a_map_group_buy.html#a612e0826d69453654a6530dcb750bfdc", null ],
    [ "ticketAddress", "interface_a_map_group_buy.html#a627eb214d83ad1f02fc6e0ec848a785d", null ],
    [ "ticketTel", "interface_a_map_group_buy.html#afba2f59166d175a38044c6bbe4b6ffe9", null ],
    [ "type", "interface_a_map_group_buy.html#aed966e6dd75bdb1037495b7fab15bdbc", null ],
    [ "typeCode", "interface_a_map_group_buy.html#acf1195f35e72aa804fb6e635be5b2265", null ],
    [ "url", "interface_a_map_group_buy.html#a97d625d3969666259ea9523a7ba52c1e", null ]
];