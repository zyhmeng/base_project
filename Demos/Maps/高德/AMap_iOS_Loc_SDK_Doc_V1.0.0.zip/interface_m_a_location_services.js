var interface_m_a_location_services =
[
    [ "apiKey", "interface_m_a_location_services.html#a2c4b76a7f0581cec9d64b5afb40198a9", null ],
    [ "SDKVersion", "interface_m_a_location_services.html#a99a92b9d2f267eb0369e314c3720e579", null ]
];