var interface_a_map_location_re_geocode =
[
    [ "adcode", "interface_a_map_location_re_geocode.html#aeab8609efd8dd3f20dbbee29744054d3", null ],
    [ "city", "interface_a_map_location_re_geocode.html#a88e2d7e7c0645857d9aa8406dac6d1d8", null ],
    [ "citycode", "interface_a_map_location_re_geocode.html#ab218130dfa6cf1be34717e0a6b789a14", null ],
    [ "district", "interface_a_map_location_re_geocode.html#a7abcc70ad6d30113218b20c6a50b0bce", null ],
    [ "formattedAddress", "interface_a_map_location_re_geocode.html#a6041dada701e0fef678ddd95ef9550e0", null ],
    [ "province", "interface_a_map_location_re_geocode.html#a29a3ecab39c96c35d15d5d54cbc07f56", null ]
];