var interface_m_a_location_manager =
[
    [ "requestLocationWithReGeocode:completionBlock:", "interface_m_a_location_manager.html#af5a21b73a701101f34f7af129e4103a4", null ],
    [ "startUpdatingLocation", "interface_m_a_location_manager.html#abec01f1fc5929c1621a124c7f5d56adf", null ],
    [ "stopUpdatingLocation", "interface_m_a_location_manager.html#afc3b1441b06658fdf3e4ef155a7e362d", null ],
    [ "allowsBackgroundLocationUpdates", "interface_m_a_location_manager.html#a6e4997aef59d436b7d581eabb2c187fa", null ],
    [ "delegate", "interface_m_a_location_manager.html#a482ee7e5a7a8cb851abbe76e9d9a95f9", null ],
    [ "desiredAccuracy", "interface_m_a_location_manager.html#af216fe4dff2abf030f9f3718b69eff14", null ],
    [ "distanceFilter", "interface_m_a_location_manager.html#a1ba1ec7c8ec5b4c12a6d533b7aad26a8", null ],
    [ "pausesLocationUpdatesAutomatically", "interface_m_a_location_manager.html#a1c5801a38dcdcecbfcdfe1df7cc541a3", null ]
];