var interface_a_map_location_manager =
[
    [ "requestLocationWithReGeocode:completionBlock:", "interface_a_map_location_manager.html#aef2f8740517aa918be616d7ded1b239b", null ],
    [ "startUpdatingLocation", "interface_a_map_location_manager.html#a0bc2df5b52b4a9ffacf671fa254e52ab", null ],
    [ "stopUpdatingLocation", "interface_a_map_location_manager.html#a72f6a93f00c057825567f76c8ef25594", null ],
    [ "allowsBackgroundLocationUpdates", "interface_a_map_location_manager.html#a0c0cce9fb06f8cc6755a45428d5d6f9f", null ],
    [ "delegate", "interface_a_map_location_manager.html#a14b5d5d43f490a69d400b26d91f6cb37", null ],
    [ "desiredAccuracy", "interface_a_map_location_manager.html#a2a698d2e5b347e48e075dfd392e04ae3", null ],
    [ "distanceFilter", "interface_a_map_location_manager.html#a7c91caba8b7a380d3de483c6841d6c11", null ],
    [ "pausesLocationUpdatesAutomatically", "interface_a_map_location_manager.html#a4fa446999c6072ccad3a5dda9e8c1dcc", null ]
];