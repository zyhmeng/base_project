var _m_a_location_common_obj_8h =
[
    [ "MALocationReGeocode", "interface_m_a_location_re_geocode.html", "interface_m_a_location_re_geocode" ],
    [ "NS_ENUM", "_m_a_location_common_obj_8h.html#a79314a93f9a16a94e5a64ea377854c8c", null ],
    [ "MALocationErrorDomain", "_m_a_location_common_obj_8h.html#acae76b4b6385262de525e29bb65ef9d7", null ]
];