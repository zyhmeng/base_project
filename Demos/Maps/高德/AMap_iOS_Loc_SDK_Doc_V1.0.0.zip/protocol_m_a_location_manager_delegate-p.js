var protocol_m_a_location_manager_delegate_p =
[
    [ "maLocationManager:didFailWithError:", "protocol_m_a_location_manager_delegate-p.html#a1e1e15f391162a785aba1a1788983fed", null ],
    [ "maLocationManager:didUpdateLocation:", "protocol_m_a_location_manager_delegate-p.html#af1ef1cea1c5542aa601ed25ab03e94eb", null ]
];