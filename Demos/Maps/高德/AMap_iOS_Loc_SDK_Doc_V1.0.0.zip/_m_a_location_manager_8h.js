var _m_a_location_manager_8h =
[
    [ "MALocationManager", "interface_m_a_location_manager.html", "interface_m_a_location_manager" ],
    [ "<MALocationManagerDelegate>", "protocol_m_a_location_manager_delegate-p.html", "protocol_m_a_location_manager_delegate-p" ],
    [ "MALocatingCompletionBlock", "_m_a_location_manager_8h.html#a500339042d8aa5027cd2899ef1e083f9", null ]
];