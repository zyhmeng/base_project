var annotated =
[
    [ "AMapLocationManager", "interface_a_map_location_manager.html", "interface_a_map_location_manager" ],
    [ "<AMapLocationManagerDelegate>", "protocol_a_map_location_manager_delegate-p.html", "protocol_a_map_location_manager_delegate-p" ],
    [ "AMapLocationReGeocode", "interface_a_map_location_re_geocode.html", "interface_a_map_location_re_geocode" ],
    [ "AMapLocationServices", "interface_a_map_location_services.html", "interface_a_map_location_services" ]
];