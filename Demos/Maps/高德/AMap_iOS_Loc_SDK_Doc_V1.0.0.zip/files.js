var files =
[
    [ "AMapLocationCommonObj.h", "_a_map_location_common_obj_8h.html", "_a_map_location_common_obj_8h" ],
    [ "AMapLocationKit.h", "_a_map_location_kit_8h.html", null ],
    [ "AMapLocationManager.h", "_a_map_location_manager_8h.html", "_a_map_location_manager_8h" ],
    [ "AMapLocationServices.h", "_a_map_location_services_8h.html", [
      [ "AMapLocationServices", "interface_a_map_location_services.html", "interface_a_map_location_services" ]
    ] ]
];