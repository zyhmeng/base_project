var searchData=
[
  ['malocatingcompletionblock',['MALocatingCompletionBlock',['../_m_a_location_manager_8h.html#a500339042d8aa5027cd2899ef1e083f9',1,'MALocationManager.h']]]
];
