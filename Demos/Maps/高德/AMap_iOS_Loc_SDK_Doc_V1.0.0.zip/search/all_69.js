var searchData=
[
  ['init',['init',['../interface_m_a_location_manager.html#a782c14447b54355e33d2334781ccdfd2',1,'MALocationManager']]]
];
