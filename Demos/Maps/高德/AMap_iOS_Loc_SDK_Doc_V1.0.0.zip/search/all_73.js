var searchData=
[
  ['sdkversion',['SDKVersion',['../interface_a_map_location_services.html#a7debff2fc3929a80288b51f6c4d40166',1,'AMapLocationServices']]],
  ['sharedservices',['sharedServices',['../interface_a_map_location_services.html#a8d9ff2c16599b4dff20555c15a3072d8',1,'AMapLocationServices']]],
  ['startupdatinglocation',['startUpdatingLocation',['../interface_a_map_location_manager.html#a0bc2df5b52b4a9ffacf671fa254e52ab',1,'AMapLocationManager']]],
  ['stopupdatinglocation',['stopUpdatingLocation',['../interface_a_map_location_manager.html#a72f6a93f00c057825567f76c8ef25594',1,'AMapLocationManager']]]
];
