var searchData=
[
  ['amaplocationmanager_3adidfailwitherror_3a',['amapLocationManager:didFailWithError:',['../protocol_a_map_location_manager_delegate-p.html#a09c67727d4d8cd4f7049691bc2c00ac6',1,'AMapLocationManagerDelegate-p']]],
  ['amaplocationmanager_3adidupdatelocation_3a',['amapLocationManager:didUpdateLocation:',['../protocol_a_map_location_manager_delegate-p.html#a604dc871dc3777a799e148790527809c',1,'AMapLocationManagerDelegate-p']]]
];
