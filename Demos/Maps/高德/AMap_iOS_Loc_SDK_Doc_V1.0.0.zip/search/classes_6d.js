var searchData=
[
  ['malocationmanager',['MALocationManager',['../interface_m_a_location_manager.html',1,'']]],
  ['malocationmanagerdelegate_2dp',['MALocationManagerDelegate-p',['../protocol_m_a_location_manager_delegate-p.html',1,'']]],
  ['malocationregeocode',['MALocationReGeocode',['../interface_m_a_location_re_geocode.html',1,'']]],
  ['malocationservices',['MALocationServices',['../interface_m_a_location_services.html',1,'']]]
];
