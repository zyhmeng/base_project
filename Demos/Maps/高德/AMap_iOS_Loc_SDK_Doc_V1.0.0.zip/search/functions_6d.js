var searchData=
[
  ['malocationmanager_3adidfailwitherror_3a',['maLocationManager:didFailWithError:',['../protocol_m_a_location_manager_delegate-p.html#a1e1e15f391162a785aba1a1788983fed',1,'MALocationManagerDelegate-p']]],
  ['malocationmanager_3adidupdatelocation_3a',['maLocationManager:didUpdateLocation:',['../protocol_m_a_location_manager_delegate-p.html#af1ef1cea1c5542aa601ed25ab03e94eb',1,'MALocationManagerDelegate-p']]]
];
