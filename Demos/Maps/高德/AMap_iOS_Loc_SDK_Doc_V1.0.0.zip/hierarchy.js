var hierarchy =
[
    [ "<NSCoding>", null, [
      [ "AMapLocationReGeocode", "interface_a_map_location_re_geocode.html", null ]
    ] ],
    [ "<NSCopying>", null, [
      [ "AMapLocationReGeocode", "interface_a_map_location_re_geocode.html", null ]
    ] ],
    [ "NSObject", null, [
      [ "AMapLocationManager", "interface_a_map_location_manager.html", null ],
      [ "AMapLocationReGeocode", "interface_a_map_location_re_geocode.html", null ],
      [ "AMapLocationServices", "interface_a_map_location_services.html", null ]
    ] ],
    [ "<NSObjectNSObject>", null, [
      [ "<AMapLocationManagerDelegate>", "protocol_a_map_location_manager_delegate-p.html", null ]
    ] ]
];