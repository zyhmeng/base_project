//
//  DistrictViewController.h
//  officialDemo2D
//
//  Created by xiaoming han on 14/11/26.
//  Copyright (c) 2014年 AutoNavi. All rights reserved.
//

#import "BaseMapViewController.h"

@interface DistrictViewController : BaseMapViewController

@end
