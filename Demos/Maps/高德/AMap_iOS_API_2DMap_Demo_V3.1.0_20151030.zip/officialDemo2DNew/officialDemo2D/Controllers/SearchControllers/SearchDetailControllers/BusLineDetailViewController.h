//
//  BusLineDetailViewController.h
//  SearchV3Demo
//
//  Created by songjian on 13-8-21.
//  Copyright (c) 2013年 songjian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AMapSearchKit/AMapSearchAPI.h>

@interface BusLineDetailViewController : UIViewController

@property (nonatomic, strong) AMapBusLine *busLine;

@end
