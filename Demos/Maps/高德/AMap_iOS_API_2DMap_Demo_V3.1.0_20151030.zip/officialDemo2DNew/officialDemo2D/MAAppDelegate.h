//
//  MAAppDelegate.h
//  officialDemo2D
//
//  Created by 刘博 on 13-9-6.
//  Copyright (c) 2013年 AutoNavi. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MAViewController;

@interface MAAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) MAViewController *viewController;

@end
