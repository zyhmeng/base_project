//
//  AppDelegate.h
//  ARKit Example
//
//  Created by Carlos on 21/10/13.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
