//
//  DetailView.h
//  ARKit Example
//
//  Created by Carlos on 25/10/13.
//
//

#import <UIKit/UIKit.h>

@interface DetailView : UIView

@property (nonatomic, strong) IBOutlet UILabel *nameLbl;

@end
